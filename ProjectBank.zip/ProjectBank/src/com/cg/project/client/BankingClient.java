package com.cg.project.client;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Scanner;

import com.cg.project.bean.AccountBean;
import com.cg.project.bean.CustomerBean;
import com.cg.project.bean.TransactionsBean;
import com.cg.project.bean.UserBean;
import com.cg.project.dao.BankingDAOImpl;
import com.cg.project.exception.BankingException;

public class BankingClient {

	public static void main(String[] args) throws SQLException, BankingException {
		BankingDAOImpl dao = new BankingDAOImpl();
		CustomerBean customer = new CustomerBean();
		AccountBean account = new AccountBean();
		TransactionsBean trans = new TransactionsBean();
		UserBean user = new UserBean();
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		/*System.out.println("Enter user id: ");
     String uid = sc.nextLine();
     System.out.println("ENTER your password");
     String pass = sc.nextLine();*/
		//dao.validate();
		System.out.println("Welcome\n1.New User press 1.\n2. Existing User press 2");
		String firstChoice = sc.next();
		switch(firstChoice){
		case "1": 
			System.out.println("Enter username");
			long uId = sc.nextLong();
			sc.nextLine();
			System.out.println("Enter password");
			String pwd1 = sc.nextLine();
	//		sc.nextLine();
			System.out.println("Re-enter your password");
			String pwd2 = sc.nextLine();
	//		sc.nextLine();
			System.out.println("Enter your Secret Question");
			String secQ = sc.nextLine();
	//		sc.nextLine();
			System.out.println("Enter your Transaction Password");
			String transPassword = sc.nextLine();
			user.setNumberId(uId);
			user.setLoginPassword(pwd2);
			user.setSecretQuestion(secQ);
			user.setTransactionPassword(transPassword);
			dao.newUserLogin(user);
			System.out.println("Now Enter Personal Details to Open Account");
			System.out.println("Dear customer enter the name: ");
			String name = sc.nextLine();
			System.out.println("Enter emailId");
			String email = sc.nextLine();
			System.out.println("Enter address");
			String address = sc.nextLine();
			System.out.println("Enter PAN card no.");
			String pan = sc.nextLine();
			System.out.println("Enter the type of account you prefer to open: \n1.Savings\n2.Current");
			int actchoice = sc.nextInt();
			String actType="";
			if(actchoice == 1)
			{
				actType = "Savings";
			}
			else
			{
				actType = "Current";
			}
	
			customer.setCustomerName(name);
			customer.setAddress(address);
			customer.setEmail(email);
			customer.setPancard(pan);
			customer.setAccountType(actType);
			dao.openAccount(customer);
//		System.out.println("Enter your Tra");
		/*System.out.println("ops to be done : 1.OpenAccount\n2.Transactions\n"
				+ "3.FundTransfer\n4.ChangeRequest\n5.TrackServices");*/
		
		case "2":
			System.out.println("Enter user Id");
			long userId = sc.nextLong();
			System.out.println("Enter Password");
			String password = sc.next();
			String validPwd = dao.validatePassword(userId);
			if(validPwd.equals(password)){
				System.out.println("Welcome to your account");
				System.out.println("ops to be done : 1.OpenAccount\n2.Transactions\n"
						+ "3.FundTransfer\n4.ChangeRequest\n5.TrackServices");
		
				String choice = sc.next();
				switch(choice)
				{
				case "1": 
					
					long actid;
					actid = dao.openAccount(customer); // insert into customer table
					//if(status!=0) {
					/*System.out.println("Thanks "+name+" your account with account id "+actid+" is "
							+ "opened with zero initial Balance");*/
					break;

				case "2":
					//Transactions....
					System.out.println("Enter your choice\n1.Deposit\n2.Withdrawl\n3.View Balance");
					String transChoice = sc.next();
					HashMap<Long,Integer> recMap = new HashMap<Long,Integer>();
					HashMap<Long,Double> amtMap = new HashMap<Long,Double>();

					switch(transChoice) {
					case "1":
						String transtype="Deposit";
						String transdesp = null;//transaction description
						//List list = new ArrayList();
						double amt = 0;
						System.out.println("Enter your account Id please:");
						long accId = sc.nextLong();
						int count = dao.validateId(accId); //validate account 
						if(count==0) {
							System.out.println("Sorry account doesn't exists...");
							sc.close();
							}
						else {
							int records = dao.fetchAccounts(accId); // checking for previous transactions...
							System.out.println(records+" fetched for this id...");
							recMap.put(accId, records);
							double initAmount = dao.fetchAmount(accId); //account balance before transaction

							System.out.println("Enter the amount to be deposited");
							double amount = sc.nextDouble();

							if(recMap.get(accId)==0)
							{
								//System.out.println("in if of deposit");
								// First Transaction and records to be inserted into accountmaster table
								transdesp = dao.deposit(accId,amount,account); // insert transaction
								if(transdesp!=null) { 
									recMap.put(accId,records+1); // transactions by accid....
									amtMap.put(accId, amount); // balance in given account after first transaction...
									amt = amtMap.get(accId); //initial balance
								}
							}
							else {
								//double amt = amtMap.get(accId);
								System.out.println("in else of deposit");
								double netAmt = initAmount+amount;
								//System.out.println(accId);
								//System.out.println(netAmt);
								transdesp = dao.depositUpdate(accId,netAmt);
								System.out.println(transdesp);
								if(transdesp!=null) {
									amtMap.put(accId,amt);//total balance after transaction in account
								}
							}
							//int transcount = dao.noOfTransactionsperId(accId);
							if(transdesp!=null)
							{
								//transcount++;
								//fetch transaction details from (accountmaster just after transaction)
								trans.setTransactionType(transtype);
								trans.setTransDescription(transdesp);
								trans.setTransactionAmount(amount);
								dao.transactionUpdate(accId,trans); // insert into transactions table....
								//set transaction details
							}
						}
						break;

					case "2" :
						//withdraw....
						transtype="Withdraw";
						transdesp = null;//transaction description
						System.out.println("Enter your account Id please:");
						accId = sc.nextLong();
						count = dao.validateId(accId); //validate account 
						if(count==0) {
							System.out.println("Sorry account doesn't exists...");
							sc.close();}
						else {
							int records = dao.fetchAccounts(accId); // checking for previous transactions...
							System.out.println(records+" fetched for this id...");
							recMap.put(accId, records);
						}
						//double initAmount = dao.fetchAmount(accId); //account balance before transaction
						//account balance before transaction
						System.out.println("Enter amount to be withdrawn");
						double amount = sc.nextDouble();
						//amount validation....			
						if(recMap.get(accId)==0)
						{
							System.out.println("sorry no records found..."); // no records to withdraw from ... 
							// First Transaction and records to be inserted into accountmaster tab
						}
						else {
							//double amt = amtMap.get(accId);
							System.out.println("in else of withdrawl");
							double initAmount = dao.fetchAmount(accId);
							double netAmt = initAmount - amount;
							if(netAmt>=0){
								//System.out.println(accId);
								//System.out.println(netAmt);
								transdesp = dao.withdraw(accId,amount);
								System.out.println(transdesp);
								if(transdesp!=null) {
									amtMap.put(accId,netAmt);//total balance after transaction in account
								}
							}
							else
							{
								System.out.println("sorry insufficient funds...");
							}
							//int transcount = dao.noOfTransactionsperId(accId);
							if(transdesp!=null)
							{
								//transcount++;
								//fetch transaction details from (accountmaster just after transaction)
								trans.setTransactionType(transtype);
								trans.setTransDescription(transdesp);
								trans.setTransactionAmount(amount);
								dao.transactionUpdate(accId,trans); // insert into transactions table....
								//set transaction details
							}
						}
						break;	

					case "3":
						//view balance .... 
						//also ministatement and detailedstatement to be made ....
						System.out.println("please enter your account id: ");
						actid = sc.nextLong();
						int status = dao.validateId(actid);
						if(status!=0){
							System.out.println("Actions\n1.View Balance\n2.Mini Statement\n3.Detailed Statement");
							String ch = sc.next();
							switch(ch){
							case "1": 
								double balance = dao.fetchAmount(actid);
								System.out.println("Balance in your account is: "+balance);
								break;
							case "2":
								HashMap<Long, TransactionsBean> miniMap = new HashMap<>();
								miniMap = dao.viewMiniStatement(actid);
								System.out.println("Mini Statement for account Id: "+actid+" is\n"+miniMap);
								break;
							case "3":
								HashMap<Long, TransactionsBean> detMap = new HashMap<>();
								detMap = dao.viewDetailedStatement(actid);
								System.out.println("Mini Statement for account Id: "+actid+" is\n"+detMap);
								break;
							}
						}
							
						else
						{
							System.out.println("Account doesn't exists...");
						}
					} //bracket of transchoice
					break;
/* Bracket of transchoice completes here*/					
////////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
				case "3":  ///////////////////////////////////
					//fund transfer ... 
					System.out.println("Enter your account id: ");
					long actId = sc.nextLong();
					int count = 0;
					//validate actid 
					count  = dao.validateId(actId);
					if(count==0){
						System.out.println("Invalid account id entered...");
						}
					//System.out.println("please enter correct id: ");
					//actId= sc.nextLong();
					else
					{
						System.out.println("Enter payee's account id: ");
						//assuming payee are the customers in records only....
						long pactId = sc.nextLong();
						int temp = dao.validateId(pactId);
						if(temp==0)
						{
							System.out.println("invalid payee id: ");
						}
						else{
							System.out.println("Enter the amount to be transfered..");
							double tamt = sc.nextDouble();
							double intAmtSender = dao.fetchAmount(actId);
							//double intAmtPayee = dao.fetchAmount(pactId);
							if(intAmtSender>=tamt)
							{
								// dao.deduct(amt,actId); // call this method in withdraw also .. 
								dao.sendfund(tamt,actId,pactId);
								// amts updated in accountmaster already for both ....
								//update transactions also for sender and reciever ..... 
								//for sender ... withdraw
								TransactionsBean transBean = new TransactionsBean();
								transBean.setTransactionAmount(tamt);
								transBean.setTransactionType("fundsent");
								transBean.setTransDescription(tamt+" sent");
								dao.transactionUpdate(actId, transBean);

								//for reciever ... 
								TransactionsBean transbean = new TransactionsBean();
								transbean.setTransactionAmount(tamt);
								transbean.setTransactionType("fundrecieved");
								transbean.setTransDescription(tamt+" recieved");
								dao.transactionUpdate(pactId, transbean);

								// System.out.println("net balance remaining in ur account is: ");
							}
							else
							{
								System.out.println("insufficient funds...");
							}
						}
					} // bracket of fund transfer
					break;

				case "4":
					//	Change Request....
					System.out.println("Enter the change request you like to perform: 1.ChangePassword\n2.ChangeAddress\n");
					String chchoice = sc.nextLine();
					switch(chchoice)
					{
					case "1": 
						System.out.println("Please enter the accountId");
						long id = sc.nextLong();
						int status = dao.validateId(id);
						if(status==0){
							System.out.println("Invalid Id...");
						}
						else{	
							System.out.println("Enter your previous password");
							for(int i=0;i<3;i++){
								String pswd1 = sc.nextLine();
								if(pswd1.equals(dao.validatePassword(id))){
									//validate
									System.out.println("Enter new password");
									String pswd2 = sc.nextLine();
									i=3;
									//insert into user table
								}
								else{
									System.out.println("Your password is not recognized");
									System.out.println("Try Again and enter your correct password");
								}
							}
						}
						break;

					} // bracket of switch(chchoice) for changing password


					break;	
				case "5":
					//service tracking ... 			
			}
			}
			else{
				System.out.println("Wrong password");
				break;
			}
			
		}		
		}	
	}