/*package com.capgemini.truckbooking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;


import java.util.List;


//import com.capgemini.dto.StudentDTO;
import com.capgemini.exception.BookingException;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.utility.DBUtil;

public class TruckDAO implements ITruckDAO {
	
	public int getBookingId() throws BookingException
	{
		// TODO Auto-generated method stub
		int bid=0;//booking id
		Connection connStudent =null;
	    PreparedStatement pst = null;
	    //ResultSet status;
		String sql = new String("SELECT booking_id_seq.nextval from dual");
		try{
			connStudent = DBUtil.createConnection();
			pst = connStudent.prepareStatement(sql);
			ResultSet bid1 = pst.executeQuery();
			while (bid1.next()) {
			 bid= bid1.getInt(1);
			}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
		}finally{
			try{
				DBUtil.closeConnection();
				//connStudent.close();
			}catch(SQLException se){
				throw new BookingException("Problems in closing connection");
			}	
		}
		return bid;
	}
	
	public void retrieveTruckDetails() throws BookingException
	{
		Connection connStudent =null;
		Statement st= null;
		try {
			connStudent = DBUtil.createConnection();
			st = connStudent.createStatement();
		    String sql1 = new String("SELECT * from truckdetails");
			ResultSet res = st.executeQuery(sql1);
			//pstStudent1.setInt(1,)
			//System.out.println("Updated details for truck booked: ");
			System.out.println("TruckId   TruckType   Origin  Destination   Charge   AvailableNos");
			System.out.println("----------------------------------------------");
			while (res.next()) {
				System.out.println(res.getInt(1)+"     "+res.getString(2)+"      "+res.getString(3)+"     "+res.getString(4)+"     "+res.getFloat(5)+"       "+res.getInt(6)); 
			}
		}catch (SQLException e) {
		}finally{
			try{
				DBUtil.closeConnection();
				//connStudent.close();
			}catch(SQLException se){
				throw new BookingException("Problems in closing connection");
			}	
		}
	}
	
	public int bookTrucks(BookingBean bookingBean) throws BookingException
	{
		int count = 0;
		Connection connStudent =null;
		PreparedStatement pst= null;
		String sql = new String("INSERT INTO bookingdetails VALUES(?,?,?,?,?,?)");
		try{
			connStudent = DBUtil.createConnection();
		//	System.out.println("***********************"+connStudent);
			pst = connStudent.prepareStatement(sql);
			pst.setInt(1,bookingBean.getBookingID());
			pst.setString(2,bookingBean.getCustId());
			pst.setLong(3,bookingBean.getCustMobile());
			pst.setInt(4,bookingBean.getTruckId());
			pst.setInt(5,bookingBean.getNoOfTrucks());
			Date utilDate = null;
			try {
				utilDate = new SimpleDateFormat("yyyy-MM-dd").parse(bookingBean.getDateOfTransport());
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
     		java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
			pst.setDate(6,sqlDate);
			//pstStudent.setString(6,bookingBean.getDateOfTransport());
			count = pst.executeUpdate();

		}catch(SQLException se)
		{
			//se.printStackTrace();
			throw new BookingException("Record not inserted: ");
		}finally{
			try{
				DBUtil.closeConnection();
			}catch(SQLException se){
				throw new BookingException("Problems in closing connection");
			}
		}
		//System.out.println(count+" results affected");
		return count;
	}
	
	public int updateTrucks(int truckId,int noOfTruckToBook) throws BookingException
	{
	
		int status=0;
		
		Connection connStudent =null;
	    PreparedStatement pst = null;
		String sql = new String("UPDATE truckdetails SET availableNos = availableNos-? WHERE truckId=?");
		try{
			connStudent = DBUtil.createConnection();
			pst = connStudent.prepareStatement(sql);
            pst.setInt(1, noOfTruckToBook);
			pst.setInt(2, truckId);
			status = pst.executeUpdate();
		}catch (SQLException e) {
		}finally{
			try{
				DBUtil.closeConnection();
			}catch(SQLException se){
				throw new BookingException("Problems in closing connection");
			}	
		}
		System.out.println(status+" records updated");
		// fetching details for mobile updated
		
		System.out.println("******Updated truck data******");
		connStudent =null;
		ResultSet res=null;
	    Statement st=null;
		try {
			connStudent = DBUtil.createConnection();
			st = connStudent.createStatement();
		    String sql1 = new String("SELECT * from truckdetails");
			res = st.executeQuery(sql1);
			//pstStudent1.setInt(1,)
			System.out.println("Updated details for truck booked: ");
			System.out.println("TruckId   TruckType   Origin  Destination   Charge   AvailableNos");
			System.out.println("----------------------------------------------");
			while (res.next()) {
				System.out.println(res.getInt(1)+"          "+res.getString(2)+"            "+res.getString(3)+"           "+res.getString(4)+"           "+res.getFloat(5)+"            "+res.getInt(6)); 
			}
		}catch (SQLException e) {
		}finally{
			try{
				DBUtil.closeConnection();
				//connStudent.close();
			}catch(SQLException se){
				throw new BookingException("Problems in closing connection");
			}	
		}
         return status;
	}

}
*/