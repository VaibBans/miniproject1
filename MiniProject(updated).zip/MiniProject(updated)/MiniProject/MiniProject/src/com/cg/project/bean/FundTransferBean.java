package com.cg.project.bean;

import java.util.Date;

public class FundTransferBean {

private String fundTransferId;
private String accountId;
private String payeeAccountId;
private Date dateOfTransfer;
private double transferAmount;

	
	
}
