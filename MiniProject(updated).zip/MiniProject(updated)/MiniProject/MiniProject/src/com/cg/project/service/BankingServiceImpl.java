package com.cg.project.service;

public class BankingServiceImpl 
{

}
